// Toolbar icon opens the side panel; right-clicking selected text looks it up there.
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.contextMenus.create({
    id: "wordbridge-lookup",
    title: "VOQUIZ: \"%s\"",
    contexts: ["selection"],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "wordbridge-lookup" || !tab) return;
  chrome.sidePanel.open({ tabId: tab.id }); // must run directly inside the click handler
  chrome.storage.session.set({ pendingTerm: { text: info.selectionText ?? "", at: Date.now() } });
});
